﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            string[] firstItem = Console.ReadLine().Split();

            var tuple1 = new Tuple<string, string, string>(firstItem[0] + " " + firstItem[1], firstItem[2], firstItem[3]);

            string[] secondItem = Console.ReadLine().Split();
            bool IsDrunk = false;
            if (secondItem[2] == "drunk")
            {
                IsDrunk = true;
            }

            var tuple2 = new Tuple<string, int, bool>(secondItem[0], int.Parse(secondItem[1]), IsDrunk);

            string[] threeItem = Console.ReadLine().Split();

            var tuple3 = new Tuple<string, double, string>(threeItem[0], double.Parse(threeItem[1]), threeItem[2]);
           
            Console.WriteLine($"{tuple1.Item1} -> {tuple1.Item2} -> {tuple1.Item3}");
            Console.WriteLine($"{tuple2.Item1} -> {tuple2.Item2} -> {tuple2.Item3}");
            Console.WriteLine($"{tuple3.Item1} -> {tuple3.Item2} -> {tuple3.Item3}");
        }
    }
}
