﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
    public class Tuple<T>
    {
        public T item1 { get; set; }
        public T item2 { get; set; }
    }
}
