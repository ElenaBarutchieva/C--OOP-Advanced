﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            
            string[] firstItem = Console.ReadLine().Split();
            var tuple1 = new Tuple<string>();
            tuple1.item1 = firstItem[0] + " " + firstItem[1];
            tuple1.item2 = firstItem[2];
            string[] secondItem = Console.ReadLine().Split();
            var tuple2 = new Tuple<string>();
            tuple2.item1 = secondItem[0];
            tuple2.item2 = secondItem[1];
            string[] threeItem = Console.ReadLine().Split();
            var tuple3 = new Tuple<string>();
            tuple3.item1 = threeItem[0];
            tuple3.item2 = threeItem[1];
            Console.WriteLine($"{tuple1.item1} -> {tuple1.item2}");
            Console.WriteLine($"{tuple2.item1} -> {tuple2.item2}");
            Console.WriteLine($"{tuple3.item1} -> {tuple3.item2}");


        }
    }
}
