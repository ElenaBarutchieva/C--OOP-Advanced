﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
    public class Box<T>
    {
        
        public List<T> items = new List<T>();

        public override string ToString()
        {
            var sb  = new StringBuilder();
            foreach (var item in items)
            {
                sb.AppendLine($"{item.GetType()}: {item}");
            }

            return sb.ToString();
        }
    }
}
