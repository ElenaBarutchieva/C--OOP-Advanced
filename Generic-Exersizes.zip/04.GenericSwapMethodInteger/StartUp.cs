﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var box = new Box<int>();
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                int currentItem = int.Parse(Console.ReadLine());
                box.items.Add(currentItem);
            }

            int[] indexes = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            var firstItem = box.items[indexes[0]];
            var secondItem = box.items[indexes[1]];
            box.items[indexes[0]] = secondItem;
            box.items[indexes[1]] = firstItem;
                
            Console.WriteLine(box.ToString());
        }
    }
}
