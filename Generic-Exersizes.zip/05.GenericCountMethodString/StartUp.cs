﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var box = new Box<string>();
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string currentItem = Console.ReadLine();
                box.items.Add(currentItem);
            }

            string itemToCompare = Console.ReadLine();

            int count = 0;

            foreach (var item in box.items)
            {
                if (item.CompareTo(itemToCompare) == 1)
                {
                    count++;
                }
            }
            Console.WriteLine(count);
        }
    }
}
