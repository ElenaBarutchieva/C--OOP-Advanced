﻿using System;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var box = new Box<int>();
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                int currentItem = int.Parse(Console.ReadLine());
                box.item = currentItem;
                Console.WriteLine(box.ToString());
            }

        }
    }
}
