﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
    public class Box<T> where T : IComparable
    {
        
        public List<T> items = new List<T>();

        public Box()
        {

        }

        public void Add(T item)
        {
            items.Add(item);
        }

        public T Remove(int index)
        {
            var itemforRemove = items[index];
            items.Remove(itemforRemove);

            return itemforRemove;
        }

        public bool Contains(T item)
        {
            if (items.Contains(item))
            {
                return true;
            }
            return false;
        }

        public void Swap(int firstIndex, int secondIndex)
        {
            var firstElement = items[firstIndex];
            var secondElement = items[secondIndex];
            items[firstIndex] = secondElement;
            items[secondIndex] = firstElement;
        }

        public int CountGreaterThan(T element)
        {
            int count = 0;

            foreach (var item in items)
            {
                if (item.CompareTo(element) == 1)
                {
                    count++;
                }
            }
            return count;
        }

        public T Max()
        {
            T maxItem =  items[0];
            foreach (var item in items)
            {
                if (item.CompareTo(maxItem) == 1)
                {
                    maxItem = item;
                }
            }
            return maxItem;
        }

        public T Min()
        {
            T minItem = items[0];
            foreach (var item in items)
            {
                if (item.CompareTo(minItem) == -1)
                {
                    minItem = item;
                }
            }
            
            return minItem;
        }
    }
}
