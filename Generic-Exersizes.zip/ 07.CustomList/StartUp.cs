﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var box = new Box<string>();

            string input = Console.ReadLine();

            while (input != "END")
            {
                string[] currentCommand = input.Split();
                switch (currentCommand[0])
                {
                    case "Add":
                        box.Add(currentCommand[1]);
                        break;
                    case "Remove":
                        box.Remove(int.Parse(currentCommand[1]));
                        break;
                    case "Contains":
                        Console.WriteLine(box.Contains(currentCommand[1]));
                        break;
                    case "Swap":
                        int first = int.Parse(currentCommand[1]);
                        int second = int.Parse(currentCommand[2]);
                        box.Swap(first, second);
                        break;
                    case "Greater":
                        Console.WriteLine(box.CountGreaterThan(currentCommand[1]));
                        break;
                    case "Max":
                        Console.WriteLine(box.Max());
                        break;
                    case "Min":
                        Console.WriteLine(box.Min());
                        break;
                    case "Print":
                        foreach (var item in box.items)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case "Sort":
                        box .items = box.items.OrderBy(x => x).ToList();
                        break;
                }
                input = Console.ReadLine();
            }
        }
    }
}
