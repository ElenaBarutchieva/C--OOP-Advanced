﻿using System;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var box = new Box<string>();
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string currentItem = Console.ReadLine();
                box.item = currentItem;
                Console.WriteLine(box.ToString());
            }

        }
    }
}
