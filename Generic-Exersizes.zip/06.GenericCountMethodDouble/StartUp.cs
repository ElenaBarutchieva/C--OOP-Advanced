﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var box = new Box<double>();
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                double currentItem = double.Parse(Console.ReadLine());
                box.items.Add(currentItem);
            }

            double itemToCompare = double.Parse(Console.ReadLine());

            double count = 0;

            foreach (var item in box.items)
            {
                if (item > itemToCompare)
                {
                    count++;
                }
            }
            Console.WriteLine(count);
        }
    }
}
