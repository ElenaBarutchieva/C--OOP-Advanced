﻿namespace TrafficLight
{
    public class Light
    {
        public string Name { get; set; }

        public int Milliseconds { get; set; }

        public Light NextLight { get; set; }
    }
}
