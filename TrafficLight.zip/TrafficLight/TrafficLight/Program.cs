﻿
namespace TrafficLight
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;

    class Program
    {
        static void Main()
        {
            string inputLightName = Console.ReadLine();

            Light currentLight = GetCurrentLight(inputLightName);

            while (true)
            {
                Console.WriteLine(currentLight.Name);
                Thread.Sleep(currentLight.Milliseconds);
                currentLight = currentLight.NextLight;
            }
        }

        static Light GetCurrentLight(string inputLightName)
        {
            Light green = new Light { Name = "Green", Milliseconds = 5000 };
            Light yellow = new Light { Name = "Yellow", Milliseconds = 1000 };
            Light red = new Light { Name = "Red", Milliseconds = 5000 };
            Light redYellow = new Light { Name = "Red-Yellow", Milliseconds = 1000 };

            green.NextLight = yellow;
            yellow.NextLight = red;
            red.NextLight = redYellow;
            redYellow.NextLight = green;

            List<Light> lights = new List<Light>()
            {
                green,
                yellow,
                red,
                redYellow
            };

            Light currentLight = lights.FirstOrDefault(x => x.Name == inputLightName);

            return currentLight;
        }
    }
}
